#### Most Powerful Features:
- Modern Design  (2017 web trends inlcuded)
- Flexibility & Fully Responsive Template
- Font Awesome 4.6.3 ( over 675+ Icons) also for menu items
- MegaMenu Generator
- Off-Canvas Menu & MegaMenu
- Article Post Formats
- Desktop,  Mobile and Retina logo option
- Advanced Typography Options - Google Fonts with update button
- Layout Manager
- Custom Layout options in Layout Builder
- Bootstrap 3.3.7
- Cross-Browser Support
and much more.

